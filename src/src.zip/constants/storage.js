export const STORAGE_KEYS = ["skill-tree-dnd-v1", "skill-tree-data-v1"];
export const THEME_KEY = "skill-tree-theme";
export const PAGE_KEY = "skill-tree-page";
export const INVENTORY_KEY = "skill-tree-inventory-v1";
